Ebib is a BibTeX database manager that runs in GNU Emacs. With Ebib, you
can create and manage .bib-files, all within Emacs. It supports @string
and @preamble definitions, multi-line field values, searching, and
integration with Emacs' (La)TeX mode.

See the Ebib manual for usage and installation instructions.

The latest release version of Ebib, contact information and mailing list
can be found at <http://ebib.sourceforge.net>. Development sources can be
found at <https://github.com/joostkremers/ebib>.

Code:
