Provides optimizations for IDO, and enables it in more places
