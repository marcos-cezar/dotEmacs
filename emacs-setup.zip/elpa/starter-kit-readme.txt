"Emacs outshines all other editing software in approximately the
same way that the noonday sun does the stars. It is not just bigger
and brighter; it simply makes everything else vanish."
-Neal Stephenson, "In the Beginning was the Command Line"

This file just brings together other pieces of the starter kit plus
user- and host-specific configs.
