This package provides the `idomenu' command for selecting an imenu tag using
ido completion.  The buffer needs to have support for imenu already enabled.

Add something like the following to your .emacs:

(autoload 'idomenu "idomenu" nil t)
